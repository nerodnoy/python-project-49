from brain_games.engine import play
from brain_games.games.gcd_game import NOD


def main():
    play(NOD)


if __name__ == '__main__':
    main()
