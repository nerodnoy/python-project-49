### Hexlet tests and linter status:
[![Maintainability](https://api.codeclimate.com/v1/badges/bdcccb94e117ba095757/maintainability)](https://codeclimate.com/github/nerodnoy/python-project-49/maintainability)
[![Actions Status](https://github.com/nerodnoy/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/nerodnoy/python-project-49/actions)

is_even game:

[![asciicast](https://asciinema.org/a/gxYTRyXnzjhfKyZQEOIRpsaGp.svg)](https://asciinema.org/a/gxYTRyXnzjhfKyZQEOIRpsaGp)

calc game:

[![asciicast](https://asciinema.org/a/BVeQtFNNTPAj2Za4739bJ7q4e.svg)](https://asciinema.org/a/BVeQtFNNTPAj2Za4739bJ7q4e)
