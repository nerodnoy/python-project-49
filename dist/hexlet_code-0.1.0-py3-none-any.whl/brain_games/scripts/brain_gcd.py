from brain_games.engine import play
from brain_games.games.gcd_game import gcd


def main():
    play(gcd)


if __name__ == '__main__':
    main()
